import './_categories.css';

function Categories() {
  return (
    <>
      <div className="categories">
        categories
      </div>
    </>
  );
}

export default Categories;
