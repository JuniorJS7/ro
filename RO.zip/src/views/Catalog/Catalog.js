import './_catalog.css';

function Catalog() {
  return (
    <>
      <div className="catalog">
        catalog
      </div>
    </>
  );
}

export default Catalog;
