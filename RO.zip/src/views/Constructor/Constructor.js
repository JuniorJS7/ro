import './_constructor.css';

function Constructor() {
  return (
    <>
      <div className="constructor">
        constructor
      </div>
    </>
  );
}

export default Constructor;
