import './_product.css';

function Product() {
  return (
    <>
      <div className="product">
        product
      </div>
    </>
  );
}

export default Product;
