import './_quesitions.css';

function Quesitions() {
  return (
    <>
      <div className="quesitions">
        Остались вопросы?
      </div>
    </>
  );
}

export default Quesitions;
