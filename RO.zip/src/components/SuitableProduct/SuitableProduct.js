import './_suitableProduct.css';

function SuitableProduct() {
  return (
    <>
      <div className="suitableProduct">
        Не нашли подходящий товар?
      </div>
    </>
  );
}

export default SuitableProduct;
