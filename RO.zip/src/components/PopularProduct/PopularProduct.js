import './_popularProduct.css';

function PopularProduct() {
  return (
    <>
      <div className="popularProduct">
        Популярные товары
      </div>
    </>
  );
}

export default PopularProduct;
