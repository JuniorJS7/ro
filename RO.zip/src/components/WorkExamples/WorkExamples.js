import './_workExamples.css';

function WorkExamples() {
  return (
    <>
      <div className="workExamples">
        Примеры наших работ:
      </div>
    </>
  );
}

export default WorkExamples;
