import './_productList.css';

function ProductList() {
  return (
    <>
      <div className="productList">
        Что вы ищите?
      </div>
    </>
  );
}

export default ProductList;
