import './_ourAdvantage.css';

function OurAdvantage() {
  return (
    <>
      <div className="ourAdvantage">
        Что вы получаете выбирая нас:
      </div>
    </>
  );
}

export default OurAdvantage;
