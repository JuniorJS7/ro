import './_learnMore.css';

function LearnMore() {
  return (
    <>
      <div className="learnMore">
        Командная форма на заказ
      </div>
    </>
  );
}

export default LearnMore;
