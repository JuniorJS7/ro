import './_slide.css';

function Slide() {
  return (
    <>
      <div className="slide">
        Slide
      </div>
    </>
  );
}

export default Slide;
